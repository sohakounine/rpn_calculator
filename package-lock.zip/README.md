# rpn_calculator
This is an reverse Polish notation calculator where we can add the numbers in postfix manner
`node app.js 2 4 +`