const calculator = require('./app.js');

//test('string with a single number should result in the number itself', () => {

// expect(calculator.reverse_polish_notation("4, 5, +")).toBe(number);

//});
test('2 ,3, += 5', () => {
    expect(calculator.reverse_polish_notation(`2, 3, +`)).toBe(number);
});
// const x = 13;
// const y = 5;
// test('Add numbers using the add method', () => {
//     expect(calculator.add(x, y)).toBe(18)
// });
// test('Subtract numbers using the subtract method', () => {
//     expect(calculator.subtract(x, y)).toBe(8)
// });
// test('Multiply numbers using the multiply method', () => {
//     expect(calculator.multiply(x, y)).toBe(65)
// });